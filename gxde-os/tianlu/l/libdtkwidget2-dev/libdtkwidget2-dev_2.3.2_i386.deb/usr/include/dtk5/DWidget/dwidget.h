#ifndef DWIDGET_H
#define DWIDGET_H

#include <QObject>
#include <QWidget>
#include "dtkwidget_global.h"

DWIDGET_BEGIN_NAMESPACE

using GWidget = QWidget;
using DWidget = QWidget;

DWIDGET_END_NAMESPACE

#endif // DWIDGET_H
