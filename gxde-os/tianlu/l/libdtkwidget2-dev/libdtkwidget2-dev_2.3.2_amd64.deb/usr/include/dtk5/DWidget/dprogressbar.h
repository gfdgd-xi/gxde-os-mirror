#ifndef DPROGRESSBAR_H
#define DPROGRESSBAR_H

#include "dtkwidget_global.h"
#include <QProgressBar>

DWIDGET_BEGIN_NAMESPACE

using DProgressBar = QProgressBar;
using GProgressBar = QProgressBar;

DWIDGET_END_NAMESPACE

#endif // DPROGRESSBAR_H
