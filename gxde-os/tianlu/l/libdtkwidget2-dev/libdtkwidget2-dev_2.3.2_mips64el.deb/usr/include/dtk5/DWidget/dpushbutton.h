#ifndef DPUSHBUTTON_H
#define DPUSHBUTTON_H

#include "dtkwidget_global.h"
#include <QObject>
#include <QPushButton>
#include <QPushButton>

DWIDGET_BEGIN_NAMESPACE

using DPushButton = QPushButton;
using GPushButton = QPushButton;

DWIDGET_END_NAMESPACE


#endif // DPUSHBUTTON_H
