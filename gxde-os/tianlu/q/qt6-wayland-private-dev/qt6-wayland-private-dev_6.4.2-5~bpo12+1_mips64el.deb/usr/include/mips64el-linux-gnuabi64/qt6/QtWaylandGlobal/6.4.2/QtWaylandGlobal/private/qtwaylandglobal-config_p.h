#define QT_FEATURE_wayland_client 1

#define QT_FEATURE_wayland_server 1

#define QT_FEATURE_wayland_egl 1

#define QT_FEATURE_wayland_brcm -1

#define QT_FEATURE_wayland_drm_egl_server_buffer 1

#define QT_FEATURE_wayland_libhybris_egl_server_buffer -1

#define QT_FEATURE_wayland_dmabuf_server_buffer 1

#define QT_FEATURE_wayland_shm_emulation_server_buffer 1

#define QT_FEATURE_wayland_vulkan_server_buffer 1

#define QT_FEATURE_wayland_datadevice 1

#define QT_FEATURE_wayland_text_input_v4_wip -1

