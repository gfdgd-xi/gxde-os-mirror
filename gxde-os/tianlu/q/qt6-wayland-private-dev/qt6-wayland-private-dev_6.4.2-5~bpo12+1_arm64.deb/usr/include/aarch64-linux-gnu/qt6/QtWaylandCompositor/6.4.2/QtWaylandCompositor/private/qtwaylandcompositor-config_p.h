#define QT_FEATURE_wayland_dmabuf_client_buffer 1

#define QT_FEATURE_wayland_layer_integration_vsp2 -1

