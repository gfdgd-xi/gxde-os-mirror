#ifndef DEPRECATED_HEADER_QtWaylandCompositor_qwaylandexport_h
#define DEPRECATED_HEADER_QtWaylandCompositor_qwaylandexport_h
#if defined(__GNUC__)
#  warning Header <QtWaylandCompositor/qwaylandexport.h> is deprecated. Please include <QtWaylandCompositor/qtwaylandcompositorglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtWaylandCompositor/qwaylandexport.h> is deprecated. Please include <QtWaylandCompositor/qtwaylandcompositorglobal.h> instead.")
#endif
#include <QtWaylandCompositor/qtwaylandcompositorglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
