#define QT_FEATURE_wayland_compositor_quick 1

