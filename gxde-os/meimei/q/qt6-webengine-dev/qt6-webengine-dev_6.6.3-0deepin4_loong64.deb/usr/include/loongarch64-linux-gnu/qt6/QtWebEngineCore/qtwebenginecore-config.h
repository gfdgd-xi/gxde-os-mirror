#define QT_FEATURE_webengine_geolocation 1

#define QT_FEATURE_webengine_webchannel 1

#define QT_FEATURE_webengine_spellchecker 1

#define QT_FEATURE_webengine_native_spellchecker -1

#define QT_FEATURE_webengine_extensions 1

