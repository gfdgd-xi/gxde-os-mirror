#define QT_FEATURE_webengine_embedded_build -1

#define QT_FEATURE_webengine_system_alsa -1

#define QT_FEATURE_webengine_v8_context_snapshot 1

#define QT_FEATURE_webengine_system_pulseaudio 1

#define QT_FEATURE_webengine_printing_and_pdf 1

#define QT_FEATURE_webengine_pepper_plugins 1

#define QT_FEATURE_webengine_proprietary_codecs 1

#define QT_FEATURE_webengine_kerberos 1

#define QT_FEATURE_webengine_webrtc 1

#define QT_FEATURE_webengine_webrtc_pipewire -1

#define QT_FEATURE_webengine_full_debug_info -1

#define QT_FEATURE_webengine_sanitizer -1

#define QT_FEATURE_webengine_vulkan 1

#define QT_FEATURE_webengine_vaapi -1

#define QT_FEATURE_webengine_system_poppler -1

