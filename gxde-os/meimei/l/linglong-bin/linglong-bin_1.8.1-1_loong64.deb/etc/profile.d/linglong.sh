#!/usr/bin/env sh

# SPDX-FileCopyrightText: 2023 UnionTech Software Technology Co., Ltd.
#
# SPDX-License-Identifier: LGPL-3.0-or-later

. "/usr/lib/linglong/generate-xdg-data-dirs.sh"

export XDG_DATA_DIRS
