#ifndef DCHECKBOX_H
#define DCHECKBOX_H

#include <QObject>
#include <QWidget>
#include <QCheckBox>

class DCheckBox: QCheckBox
{
public:
    DCheckBox();
};

#endif // DCHECKBOX_H
