#include "gsgpu.h"
#include "gsgpu_drm.h"

#define CREATE_TRACE_POINTS
#include "gsgpu_trace.h"
