#ifndef __GSGPU_COMMON_H__
#define __GSGPU_COMMON_H__

#define VI_FLUSH_GPU_TLB_NUM_WREG	3

int gsgpu_set_ip_blocks(struct gsgpu_device *adev);

#endif /*__GSGPU_COMMON_H__*/
