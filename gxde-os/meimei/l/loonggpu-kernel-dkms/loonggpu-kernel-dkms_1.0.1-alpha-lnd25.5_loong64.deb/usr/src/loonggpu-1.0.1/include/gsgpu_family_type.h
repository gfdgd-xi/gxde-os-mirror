#ifndef __GSGPU_FAMILY_TYPE_H__
#define __GSGPU_FAMILY_TYPE_H__
/*
 * Supported FAMILY types
 */
enum gsgpu_family_type {
	CHIP_LG100 = 0,
};

#endif /*__GSGPU_FAMILY_TYPE_H__ */
