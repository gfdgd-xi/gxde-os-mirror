#ifndef __GFX_H__
#define __GFX_H__

extern const struct gsgpu_ip_block_version gfx_ip_block;

struct gsgpu_device;

#endif /*__GFX_H__*/
