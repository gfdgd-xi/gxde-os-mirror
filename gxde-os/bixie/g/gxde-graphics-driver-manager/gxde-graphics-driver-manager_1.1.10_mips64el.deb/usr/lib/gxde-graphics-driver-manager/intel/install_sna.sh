#!/bin/bash

/usr/lib/deepin-graphics-driver-manager/intel/install_intel_opensource.sh 2
