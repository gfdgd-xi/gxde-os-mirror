#!/bin/sh

su -c 'gvfs-open '"$1" - $2
