// Copyright (C) 2023 JiDe Zhang <zccrs@live.com>.
// SPDX-License-Identifier: Apache-2.0 OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#define WLR_HAVE_DRM_BACKEND true
#define WLR_HAVE_X11_BACKEND true
#define WLR_HAVE_LIBINPUT_BACKEND true
#define WLR_HAVE_XWAYLAND true
#define WLR_HAVE_GLES2_RENDERER true
#define WLR_HAVE_VULKAN_RENDERER true
#define WLR_HAVE_GBM_ALLOCATOR true
#define WLR_HAVE_SESSION true

#define WLR_VERSION "0.18.2"
#define WLR_VERSION_MAJOR 0
#define WLR_VERSION_MINOR 18
#define WLR_VERSION_PATCH 2
